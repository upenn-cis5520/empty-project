import Execute
import Lib
import Test.HUnit
import Test.QuickCheck
import Types

main :: IO ()
main = do
  putStrLn someFunc
  putStrLn "Test suite not yet implemented"

instance Arbitrary Row where
  arbitrary :: Gen Row
  arbitrary = genTree
  shrink :: (Arbitrary a) => Tree a -> [Tree a]
  shrink = shrinkTree
